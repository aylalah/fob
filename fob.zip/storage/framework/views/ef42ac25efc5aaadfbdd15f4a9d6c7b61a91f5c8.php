

<!-- <?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?> -->

<?php $__env->startSection('breadcrumb'); ?>
     
							
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
              
<div id="page-content">
		<div class="container">
			<div class="row">
				<div class="col-sm-8 page-content">
					<div class="white-container mb0">
						<div class="title-lines">
							<h3 class="mt15"><?php echo e($abt->heading); ?></h3>
						</div>

						<!-- <p><strong>This website is all about a platform to help Discover talents, create benefits for talents, promote talents and get talent some sweet deals. Talent here is not only based on entertainment but also any creativity.</strong></p> -->

						<p style="white-space: pre-line;"><?php echo e($abt->content); ?></p>

						<div class="fitvidsjs">
							<iframe src="//<?php echo e($abt->video); ?>" width="500" height="281" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
						</div>

						<!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Facere, consequatur, ratione itaque totam ea blanditiis eius odit at sapiente cum numquam illo. Eligendi, natus, nihil, nemo, voluptates atque quo illum deleniti earum magni optio cupiditate nobis labore fuga vero voluptatem sed autem quasi culpa tempore suscipit delectus reprehenderit animi dolores!</p> -->

						<h3 class="bottom-line">Our Team</h3>

						<div class="row">
							 <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
							<div class="col-sm-6 col-md-4">
								<div class="our-team-item">
									<div class="img">
										   <img  src="http://localhost/fob/storage/app/<?php echo e($t->image); ?>" alt="" />
									</div>

									<h6><?php echo e($t->team_name); ?> <span><?php echo e($t->designation); ?></span></h6>
								</div>
							</div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
							
						</div>
					</div>
				</div>

				<div class="col-sm-4 page-sidebar">
					<aside>
						<div class="widget sidebar-widget white-container links-widget">
							<ul>
								<li class="active"><a href="<?php echo e(url('/about')); ?>">About Us</a></li>
								<li><a href="<?php echo e(url('/privacy-policy')); ?>">Privacy Policy</a></li>
								<li><a href="<?php echo e(url('/term-condition')); ?>">Terms &amp; Conditions</a></li>
							</ul>
						</div>
					</aside>
				</div>
			</div>
		</div> <!-- end .container -->
	</div> <!-- end #page-content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\fob\resources\views/Pages/about.blade.php ENDPATH**/ ?>