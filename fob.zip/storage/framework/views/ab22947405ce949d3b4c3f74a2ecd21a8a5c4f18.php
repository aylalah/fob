

<?php $__env->startSection('content'); ?>
<!-- <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('You are logged in!')); ?>

                </div>
            </div>
        </div>
    </div>
</div> -->

<?php if(Auth::user()->user_category_id == 1): ?>  
 
	 <?php endif; ?>

<?php if(Auth::user()->username !== null): ?>   

<div id="page-content">
		<div class="container">
			<div class="row">
				<div class="col-sm-4 page-sidebar">
					<aside>
						<div class="widget sidebar-widget white-container candidates-single-widget">
							<div class="widget-content">
								<div class="thumb">
									<img src="http://localhost/fob/public/upload/<?php echo e(Auth::user()->image); ?>" alt="">
								</div>

								<h5 class="bottom-line"><?php echo e($user->category_name); ?> Details</h5>

								<table>
									<tbody>
										<tr>
											<td>Name</td>
											<td><?php echo e(Auth::user()->name); ?></td>
										</tr>
								 <?php if(Auth::user()->age !== null): ?>  
										<tr>
											<td>Age</td>
											<td><?php echo e(Auth::user()->age); ?></td>
										</tr>
 								 <?php endif; ?>

  									 <?php if(Auth::user()->address_1 !== null): ?>  
										<tr>
											<td>Address</td>
											<td><?php echo e(Auth::user()->address_1); ?></td>
										</tr>
										  <?php endif; ?>

										 <?php if(Auth::user()->address_2 !== null): ?>    
											<tr>
											<td>Address 2</td>
											<td><?php echo e(Auth::user()->address_2); ?></td>
										</tr>
										  <?php endif; ?>

										  <?php if(Auth::user()->state !== null): ?>   
										<tr>
											<td>State</td>
											<td><?php echo e(Auth::user()->state); ?></td>
										</tr>
 									 <?php endif; ?>

  									<?php if(Auth::user()->country !== null): ?>   
										<tr>
											<td>Country</td>
											<td><?php echo e(Auth::user()->country); ?></td>
										</tr>
 									 <?php endif; ?>

										<?php if(Auth::user()->city !== null): ?>   
										<tr>
											<td>City</td>
											<td><?php echo e(Auth::user()->city); ?></td>
										</tr>
  										<?php endif; ?>

 										 <?php if(Auth::user()->contact !== null): ?>   
										<tr>
											<td>Phone</td>
											<td><?php echo e(Auth::user()->contact); ?></td>
										</tr>
										  <?php endif; ?>

 							 		<?php if(Auth::user()->contact2 !== null): ?>    
										<tr>
											<td>Phone 2</td>
											<td><?php echo e(Auth::user()->contact2); ?></td>
										</tr>
										   <?php endif; ?>

										<tr>
											<td>E-mail</td>
											<td><a target="_blank" href="mailto:<?php echo e(Auth::user()->email); ?>"><?php echo e(Auth::user()->email); ?></a></td>
										</tr>
									<!-- <?php if(Auth::user()->website !== null): ?>   
										<tr>
											<td>Website</td>
											<td><a href="<?php echo e(Auth::user()->website); ?>" target=""><?php echo e(Auth::user()->website); ?></a></td>
										</tr>
										  <?php endif; ?> -->
									</tbody>
								</table>
					<?php if(Auth::user()->user_category_id == 2): ?> 
								<h5 class="bottom-line"></h5>

								<!-- <table>
									<tbody>
										<tr>
											<td>Expertise</td>
											<td>
												<ul class="stars">
													<li><i class="fa fa-star"></i></li>
													<li><i class="fa fa-star"></i></li>
													<li><i class="fa fa-star"></i></li>
													<li><i class="fa fa-star-o"></i></li>
													<li><i class="fa fa-star-o"></i></li>
												</ul>
											</td>
										</tr>

										<tr>
											<td>Knowledge</td>
											<td>
												<ul class="stars">
													<li><i class="fa fa-star"></i></li>
													<li><i class="fa fa-star"></i></li>
													<li><i class="fa fa-star"></i></li>
													<li><i class="fa fa-star"></i></li>
													<li><i class="fa fa-star-o"></i></li>
												</ul>
											</td>
										</tr>

										<tr>
											<td>Quality</td>
											<td>
												<ul class="stars">
													<li><i class="fa fa-star"></i></li>
													<li><i class="fa fa-star"></i></li>
													<li><i class="fa fa-star"></i></li>
													<li><i class="fa fa-star"></i></li>
													<li><i class="fa fa-star"></i></li>
												</ul>
											</td>
										</tr>

										<tr>
											<td>Price</td>
											<td>
												<ul class="stars">
													<li><i class="fa fa-star"></i></li>
													<li><i class="fa fa-star"></i></li>
													<li><i class="fa fa-star-o"></i></li>
													<li><i class="fa fa-star-o"></i></li>
													<li><i class="fa fa-star-o"></i></li>
												</ul>
											</td>
										</tr>

										<tr>
											<td>Services</td>
											<td>
												<ul class="stars">
													<li><i class="fa fa-star"></i></li>
													<li><i class="fa fa-star"></i></li>
													<li><i class="fa fa-star"></i></li>
													<li><i class="fa fa-star"></i></li>
													<li><i class="fa fa-star-o"></i></li>
												</ul>
											</td>
										</tr>
									</tbody>
								</table> -->
								<aside>
						<div class="widget sidebar-widget white-container links-widget">
							<ul>
								<li class="active"><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
								<li><a href="<?php echo e(url('/favourite')); ?>">Favourite</a></li>
							</ul>
						</div>
					</aside>

					<?php endif; ?>
					
					<h5 class="bottom-line"></h5>
					<?php if(Auth::user()->user_category_id == 4): ?>
					<aside>
						<div class="widget sidebar-widget white-container links-widget">
							<ul>
								<li class="active"><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
								<li><a href="<?php echo e(url('/favourite')); ?>">Favourite</a></li>
								<li><a href="<?php echo e(url('/term-condition')); ?>">Sponsor</a></li>
							</ul>
						</div>
					</aside>

					<?php endif; ?>
							</div>
						</div>
					</aside>
				</div> <!-- end .page-sidebar -->

				<div class="col-sm-8 page-content">
					<!-- <div class="clearfix mb30 hidden-xs">
						<a href="#" class="btn btn-gray pull-left">Back to Listings</a>
						<div class="pull-right">
							<a href="#" class="btn btn-gray">Previous</a>
							<a href="#" class="btn btn-gray">Next</a>
						</div>
					</div> -->
					<!-- Member or Talent -->
<?php if(Auth::user()->user_category_id == 2): ?>   
<?php if($d): ?> 

					<div class="candidates-item candidates-single-item">
						<h6 class="title"><a ><?php echo e(Auth::user()->name); ?></a></h6>
						<span class="meta"><?php echo e($d->age); ?> Years Old </span>

						<ul class="top-btns">
							<li><a href="#" class="btn btn-gray fa fa-star"></a></li>
						</ul>

						

						<p style="white-space: pre-line;"><?php echo e($d->about); ?></p>

					<!-- 	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ea, nihil, dolores, culpa ullam vero ipsum placeat accusamus nemo ipsa cupiditate id molestiae consectetur quae pariatur repudiandae vel ex quaerat nam iusto aliquid laborum quia adipisci aut ut impedit obcaecati nisi deleniti tempore maxime sequi fugit reiciendis libero quo. Rerum, assumenda.</p>

						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Exercitationem, at nemo inventore temporibus corporis suscipit.</p> -->

						<ul class="list-unstyled">
								<li><strong>Experience:</strong> <?php echo e($d->experience); ?></li>
								<li><strong>Degree:</strong> <?php echo e($d->degree); ?></li>
								<li><strong>Career Level:</strong> <?php echo e($d->talent_level); ?></li>
								<li><strong>Website:</strong><a href="<?php echo e($d->website); ?>" target="_blank"> <?php echo e($d->website); ?></a> </li>
							</ul>

							<h5>Skills</h5>

							<hr>
							<div class="progress-bar toggle" data-progress="<?php echo e($d->rate_1); ?>">
								<a href="#" class="progress-bar-toggle"></a>
								<h6 class="progress-bar-title"><?php echo e($d->skill_1); ?></h6>
								<div class="progress-bar-inner"><span></span></div>
								<div class="progress-bar-content">
									<?php echo e($d->reason_1); ?>

								</div>
							</div>
<?php if($d->skill_2 != null): ?> 
							<div class="progress-bar toggle" data-progress="<?php echo e($d->rate_2); ?>">
								<a href="#" class="progress-bar-toggle"></a>
								<h6 class="progress-bar-title"><?php echo e($d->skill_2); ?></h6>
								<div class="progress-bar-inner"><span></span></div>
								<div class="progress-bar-content">
									<?php echo e($d->reason_2); ?>

								</div>
							</div>
							 <?php endif; ?>
							<?php if($d->skill_3 != null): ?> 
							<div class="progress-bar toggle" data-progress="<?php echo e($d->rate_3); ?>">
								<a href="#" class="progress-bar-toggle"></a>
								<h6 class="progress-bar-title"><?php echo e($d->skill_3); ?></h6>
								<div class="progress-bar-inner"><span></span></div>
								<div class="progress-bar-content">
									<?php echo e($d->reason_3); ?>

								</div>
							</div>

					 <?php endif; ?>
						<hr>

						<div class="clearfix">
								<a href="mailto:<?php echo e(Auth::user()->email); ?>" class="btn btn-default pull-left"><i class="fa fa-envelope-o"></i> Contact Me</a>

								<ul class="social-icons pull-right">
									<li><span>Share</span></li>
									<li><a href="<?php echo e($d->facebook); ?>" class="btn btn-gray fa fa-facebook" target="_blank"></a></li>
							<li><a href="<?php echo e($d->twitter); ?>" class="btn btn-gray fa fa-twitter" target="_blank"></a></li>
							<li><a href="<?php echo e($d->instagram); ?>" class="btn btn-gray fa fa-instagram" target="_blank"></a></li>
							
								</ul>
							</div>
					</div>
  <?php endif; ?>
 <?php endif; ?>




<!-- Investor -->
<?php if(Auth::user()->user_category_id == 4): ?> 
<?php if($invest): ?> 
					<div class="candidates-item candidates-single-item">
						
						<h6 class="title"><a ><?php echo e($invest->ceo_name); ?></a></h6>
						

						<ul class="top-btns">
							<li><a href="#" class="btn btn-gray fa fa-star"></a></li>
						</ul>

						<ul class="social-icons clearfix">
							<li><a href="<?php echo e($invest->facebook); ?>" class="btn btn-gray fa fa-facebook"  target="_blank"></a></li>
							<li><a href="<?php echo e($invest->twitter); ?>" class="btn btn-gray fa fa-twitter" target="_blank"></a></li>
							<li><a href="<?php echo e($invest->instagram); ?>" class="btn btn-gray fa fa-instagram" target="_blank"></a></li>
							
						</ul>

						<!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Suscipit, maxime, excepturi, mollitia, voluptatibus similique aliquid a dolores autem laudantium sapiente ad enim ipsa modi laborum accusantium deleniti neque architecto vitae.</p>

						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ea, nihil, dolores, culpa ullam vero ipsum placeat accusamus nemo ipsa cupiditate id molestiae consectetur quae pariatur repudiandae vel ex quaerat nam iusto aliquid laborum quia adipisci aut ut impedit obcaecati nisi deleniti tempore maxime sequi fugit reiciendis libero quo. Rerum, assumenda.</p>

						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Exercitationem, at nemo inventore temporibus corporis suscipit.</p>
 -->
						<ul class="list-unstyled">
							<li><strong>Company Name:</strong><?php echo e($invest->company_industry_category); ?></li>
							<li><strong>Company Profile:</strong> <?php echo e($invest->company_profile); ?></li>
							<li><strong>Website:</strong><a href="<?php echo e($invest->website); ?>" target="_blank"> <?php echo e($invest->website); ?></a> </li>
						</ul>

				
						<hr>

						<!-- <div class="clearfix">
							<a href="#" class="btn btn-default pull-left"><i class="fa fa-envelope-o"></i> Contact Me</a>

							<ul class="social-icons pull-right">
								<li><span>Share</span></li>
								<li><a href="#" class="btn btn-gray fa fa-facebook"></a></li>
								<li><a href="#" class="btn btn-gray fa fa-twitter"></a></li>
								<li><a href="#" class="btn btn-gray fa fa-google-plus"></a></li>
							</ul>
						</div> -->
					</div>
					 <?php endif; ?>	
  <?php endif; ?>
					<div class="title-lines">
						<h3 class="mt0">Similar Candidates</h3>
					</div>
 <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     
   <?php echo e($d->id); ?>

   <?php 
       $like=\App\Like::where('user_id','=',Auth::id())->where('talent_id','=',$d->id)->select(DB::raw('count(*) as like_count, status'))->groupBy('status')->first();
        $countf=\App\favourite::where('user_id','=',Auth::id())->where('f_user_id','=',$d->user_id)->select(DB::raw('count(*) as count, status'))->groupBy('status')->first();
        if ($like) {
        $count_status=$like->like_count;
        $type = $like->status;
      // echo $type;
    }else{
    	$type=1;
    	// echo $type;
    }
  
       if ($countf) {
        // $count_status=$l->like_count;
        $status = $countf->status;
      // echo $type;
    }else{
    	$status=1;
    	// echo $type;
    }   
    
?>	
  <?php if(Auth::user()->id != $d->user_id): ?>  

					<div class="candidates-item">
						<div class="thumb"><img src="http://localhost/fob/public/upload/<?php echo e($d->image); ?>" alt=""></div>

						<h6 class="title"><a href="#"><?php echo e($d->name); ?></a></h6>
						<span class="meta"><?php echo e($d->age); ?> Years Old 
						<!-- - Sydney, AU -->
					</span>

						<ul class="top-btns">
							<li><a href="#" class="btn btn-gray fa fa-plus toggle"></a></li>
							<?php if($status == '1'): ?> 
							<li><a id="fav1_<?php echo e($d->user_id); ?>" class="btn btn-gray fa fa-star fav fav1_<?php echo e($d->user_id); ?>"></a></li>
							<?php endif; ?>
							<?php if($status == '2'): ?> 	
							<li><a id="fav2_<?php echo e($d->user_id); ?>" class="btn btn-default fa fa-star fav fav2_<?php echo e($d->user_id); ?>"></a></li>
								<?php endif; ?>
							<?php if($type == '1'): ?> 
							<li><a id="like1_<?php echo e($d->id); ?>" class="btn btn-gray fa fa-thumbs-up like like1_<?php echo e($d->id); ?>"><?php echo e($d->count_like); ?></a></li>
							<?php endif; ?>
							<?php if($type == '2'): ?> 	
							<li><a id="like2_<?php echo e($d->id); ?>" class="btn btn-default fa fa-thumbs-up like like2_<?php echo e($d->id); ?>"><?php echo e($d->count_like); ?></a></li>
								<?php endif; ?>
							<!-- <li><a href="#" class="btn btn-gray fa fa-star"></a></li>
							<li><a href="#" class="btn btn-gray fa fa-link"></a></li> -->
						</ul>

						<p class="description"><?php echo e($d->about); ?> <a href="#" class="read-more">Read More</a></p>

						<div class="clearfix"></div>

						<div class="content">
							<!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ea, nihil, dolores, culpa ullam vero ipsum placeat accusamus nemo ipsa cupiditate id molestiae consectetur quae pariatur repudiandae vel ex quaerat nam iusto aliquid laborum quia adipisci aut ut impedit obcaecati nisi deleniti tempore maxime sequi fugit reiciendis libero quo. Rerum, assumenda.</p>

							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Exercitationem, at nemo inventore temporibus corporis suscipit.</p> -->

							<ul class="list-unstyled">
								<li><strong>Experience:</strong> <?php echo e($d->experience); ?></li>
								<li><strong>Degree:</strong> <?php echo e($d->degree); ?></li>
								<li><strong>Career Level:</strong> <?php echo e($d->talent_level); ?></li>
							</ul>

							<h5>Skills</h5>

							<div class="progress-bar toggle" data-progress="<?php echo e($d->rate_1); ?>">
								<a href="#" class="progress-bar-toggle"></a>
								<h6 class="progress-bar-title"><?php echo e($d->skill_1); ?></h6>
								<div class="progress-bar-inner"><span></span></div>
								<div class="progress-bar-content">
									<?php echo e($d->reason_1); ?>

								</div>
							</div>

						<?php if($d->skill_2 != null): ?> 
							<div class="progress-bar toggle" data-progress="<?php echo e($d->rate_2); ?>">
								<a href="#" class="progress-bar-toggle"></a>
								<h6 class="progress-bar-title"><?php echo e($d->skill_2); ?></h6>
								<div class="progress-bar-inner"><span></span></div>
								<div class="progress-bar-content">
									<?php echo e($d->reason_2); ?>

								</div>
							</div>
							 <?php endif; ?>
							<?php if($d->skill_3 != null): ?> 
							<div class="progress-bar toggle" data-progress="<?php echo e($d->rate_3); ?>">
								<a href="#" class="progress-bar-toggle"></a>
								<h6 class="progress-bar-title"><?php echo e($d->skill_3); ?></h6>
								<div class="progress-bar-inner"><span></span></div>
								<div class="progress-bar-content">
									<?php echo e($d->reason_3); ?>

								</div>
							</div>

					 <?php endif; ?>

							<hr>

							<div class="clearfix">
								<a href="mailto:<?php echo e($d->email); ?>" class="btn btn-default pull-left"><i class="fa fa-envelope-o"></i> Contact Me</a>

								<ul class="social-icons pull-right">
									<li><span>Share</span></li>
									<li><a href="<?php echo e($d->facebook); ?>" class="btn btn-gray fa fa-facebook" target="_blank"></a></li>
							<li><a href="<?php echo e($d->twitter); ?>" class="btn btn-gray fa fa-twitter" target="_blank"></a></li>
							<li><a href="<?php echo e($d->instagram); ?>" class="btn btn-gray fa fa-instagram" target="_blank"></a></li>
							
								</ul>
							</div>
						</div>
					</div>
					

   <?php endif; ?>
   
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
							<hr>

							<!-- <div class="clearfix">
								<a href="#" class="btn btn-default pull-left"><i class="fa fa-envelope-o"></i> Contact Me</a>

								<ul class="social-icons pull-right">
									<li><span>Share</span></li>
									<li><a href="#" class="btn btn-gray fa fa-facebook"></a></li>
									<li><a href="#" class="btn btn-gray fa fa-twitter"></a></li>
									<li><a href="#" class="btn btn-gray fa fa-google-plus"></a></li>
								</ul>
							</div> -->
						</div>
					</div>
				</div> <!-- end .page-content -->
			</div>
		</div> <!-- end .container -->
	</div> <!-- end #page-content -->
<?php else: ?>
<?php if(Auth::user()->user_category_id == 2): ?>  
 <?php echo $__env->make('auth.register-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	 <?php endif; ?>

	 <?php if(Auth::user()->user_category_id == 4): ?> 
<?php echo $__env->make('auth.register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php endif; ?>

	<?php endif; ?> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\fob\resources\views/home2.blade.php ENDPATH**/ ?>