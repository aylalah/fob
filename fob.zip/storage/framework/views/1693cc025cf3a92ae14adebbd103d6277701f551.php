

<?php $__env->startSection('content'); ?>
<div id="page-content">
		<div class="container">
			<div class="row">
				<div class="col-sm-12 page-content">
					<ul class="form-steps four clearfix">
						<li class="active">Step 1</li>
						<li>Step 2</li>
						<li>Step 3</li>
						<li>Step 4</li>
					</ul>

					<div class="white-container sign-up-form">	<div>

					<form method="POST" action="<?php echo e(url('register-user')); ?>" enctype="multipart/form-data">
						<?php echo csrf_field(); ?>
						<h2>1. Fill in your Personal profile</h2>

						<section>
								<h6 class="bottom-line">Personal Info:</h6>

								<h6 class="label">Name</h6>

								<div class="row">
									<div class="col-sm-4">
										<!-- <input type="text" class="form-control" placeholder="Name"> -->
										<input id="name" type="text"  placeholder="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(Auth::user()->name); ?>" required autocomplete="name" disabled>
										
									</div>

									
								
								</div>		

								<h6 class="label">Email</h6>
								<div class="row">
									<div class="col-sm-4">
										<!-- <input type="text" class="form-control" placeholder="Surname"> -->
										<input id="email" type="email"  placeholder="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(Auth::user()->email); ?>" required autocomplete="email" disabled>

										
									</div>
</div>
								<h6 class="label">Phone</h6>

								<div class="row">
									<div class="col-sm-4">
										
										<input id="contact" type="number" placeholder="Mobile" class="form-control <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="contact" value="<?php echo e(old('contact')); ?>" required autocomplete="contact" autofocus>

										<?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>

									<div class="col-sm-4">
									<input id="contact2" type="number" placeholder="Mobile 2" class="form-control <?php $__errorArgs = ['contact2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="contact2" value="<?php echo e(old('contact2')); ?>" autocomplete="contact2">

										<?php $__errorArgs = ['contact2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>

									<!-- <div class="col-sm-4">
										<input type="text" class="form-control" placeholder="Fax">
									</div> -->
								</div>

								<h6 class="label">Address</h6>

								<div class="row">
									<div class="col-sm-6">
										<input type="hidden" class="form-control" value="2" name="user_category_id">

										<input id="address_1" type="text" placeholder="Address 1" class="form-control <?php $__errorArgs = ['address_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="address_1" value="<?php echo e(old('address_1')); ?>" required autocomplete="address_1">

										<?php $__errorArgs = ['address_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										
									</div>

									<div class="col-sm-6">
										<!-- <input type="text" class="form-control" placeholder="Address 2"> -->

										<input id="address_2" type="text" placeholder="Address 2" class="form-control <?php $__errorArgs = ['address_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="address_2" value="<?php echo e(old('address_2')); ?>" autocomplete="address_2">

										<?php $__errorArgs = ['address_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>

								<div class="row">
									<div class="col-sm-3">
										<select  id="country" class="form-control <?php $__errorArgs = ['address_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="address_2" value="<?php echo e(old('address_2')); ?>" required autocomplete="address_2">
											<option value="">Country</option>
											<option value="">Nigeria</option>
											<option value="">South Africa</option>
											<option value="">Gana</option>
											<option value="">United State</option>
											<option value="">United Kingdom</option>
										</select>
									</div>

									<div class="col-sm-3">
									<input id="state" type="text" placeholder="State" class="form-control <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="state" value="<?php echo e(old('state')); ?>" autocomplete="state">

										<?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>

									<div class="col-sm-3">
									<input id="city" type="text" placeholder="city" class="form-control <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="city" value="<?php echo e(old('city')); ?>" autocomplete="state">

									<?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<span class="invalid-feedback" role="alert">
											<strong><?php echo e($message); ?></strong>
										</span>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>

									<!-- <div class="col-sm-3">
										<input type="text" class="form-control" placeholder="ZIP Code">
									</div> -->
								</div>
								
							</section>
								
						<hr class="mt60">							

							<h2>2. Upload</h2>

							<section>
								<h6 class="label">Upload profile</h6>
								<div class="row">
									<div class="col-sm-4">
<input type="file" class="form-control" name="file">
									</div>
								</div>
							</section>
								
							<hr class="mt60">

							<h2>3. Choose Talent Category</h2>

							<section>
								<h6 class="bottom-line">You are:</h6>

								<?php $__currentLoopData = $getCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                                  
									<div class="radio-inline">
										<label><input type="radio" id="<?php echo e($gCat->id); ?>" name="talent_category_id" value="<?php echo e($gCat->id); ?>" required ><?php echo e($gCat->talentcategory_name); ?> </label>
									</div>              
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
							</section>

							<hr class="mt60">	

							<h2>4. Fill in your Talent profile</h2>

						<section>
								<h6 class="bottom-line">Talent Info:</h6>

								<h6 class="label">Disribe your Talent <i style="color:red; font-size:10px">Not more that 150 words</i></h6>
								<div class="row">
									<div class="col-sm-6">
										<!-- <input type="text" class="form-control" placeholder="Surname"> -->
										<textarea id="about" type="text"  placeholder="About" class="form-control <?php $__errorArgs = ['about'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="about" autocomplete="about" required></textarea>

										<?php $__errorArgs = ['about'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>

								<h6 class="label">Social Handles Links</h6>

								<div class="row">
									<div class="col-sm-4">
										<!-- <input type="text" class="form-control" placeholder="Name"> -->
										<input id="instagram" type="text"  placeholder="Instagram" class="form-control <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="instagram" value="<?php echo e(old('instagram')); ?>" autocomplete="instagram" >
										<?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>

									<div class="col-sm-4">										
										<input id="twitter" type="text"  placeholder="Twitter" class="form-control <?php $__errorArgs = ['twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="twitter" value="<?php echo e(old('twitter')); ?>" autocomplete="twitter" autofocus>
										<!-- <input name="user_category_id" type="hidden" value="2"> -->
										<?php $__errorArgs = ['twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>

									<div class="col-sm-4">									
										<input id="facebook" type="text"  placeholder="Facebook" class="form-control <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="facebook" value="<?php echo e(old('facebook')); ?>"  autocomplete="facebook" autofocus>
										<!-- <input name="user_category_id" type="hidden" value="2"> -->
										<?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>

								<h6 class="label">Date of Birth</h6>

								<div class="row">
									<div class="col-sm-4">
										<input type="text" class="form-control" placeholder="MM/DD/YYYY" name="date_of_birth">
									</div>
									<div class="col-sm-4">
										
										

										<input id="age" type="age" class="year-input" placeholder="Age" class="form-control <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="age" value="<?php echo e(old('age')); ?>" autocomplete="age">
									</div>
								</div>

								<h6 class="label">Gender</h6>
								<div class="row">
									<div class="col-sm-4">
									<div class="radio-inline">
										<label><input type="radio" id="male" name="sex" value="Male"  >Male</label>										
									</div> 
									<div class="radio-inline">										
										<label><input type="radio" id="Female" name="sex" value="Female"  >Female</label>
									</div> 
									</div>
								</div>

								<h6 class="label">Experience</h6>

								<div class="row">
									<div class="col-sm-6">
										
										<input id="experience" type="text" placeholder="Experience" class="form-control <?php $__errorArgs = ['experience'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="experience" value="<?php echo e(old('experience')); ?>" autocomplete="experience" required>

										<?php $__errorArgs = ['experience'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>

								
								<h6 class="label">Talent Level</h6>

								<div class="row">
									<div class="col-sm-6">
										
										<input id="talent_level" type="text" placeholder="Talent Level" class="form-control <?php $__errorArgs = ['talent_level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="talent_level" value="<?php echo e(old('talent_level')); ?>" autocomplete="talent_level" required>

										<?php $__errorArgs = ['talent_level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>

								<h6 class="label">Degree</h6>

								<div class="row">
									<div class="col-sm-6">
										
										<input id="degree" type="text" placeholder="Degree" class="form-control <?php $__errorArgs = ['degree'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="degree" value="<?php echo e(old('degree')); ?>" autocomplete="degree" required>

										<?php $__errorArgs = ['degree'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>

								<h6 class="label">Website</h6>

								<div class="row">
									<div class="col-sm-6">
										
										<input id="website" type="text" placeholder="website" class="form-control <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="website" value="<?php echo e(old('website')); ?>" autocomplete="website">

										<?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>

								<h6 class="label">Skill Rate 1</h6>

								<div class="row">
									
									<div class="col-sm-4">										

										<input id="skill_1" type="text" placeholder="Enter a Skill Pertaining to your talent here" class="form-control <?php $__errorArgs = ['skill_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="skill_1" value="<?php echo e(old('skill_1')); ?>" autocomplete="skill_1" required>
																		
									</div>

									<div class="col-sm-4">										

										<input id="rate_1" type="number" placeholder="Rate your Skill Mentioned" class="form-control <?php $__errorArgs = ['rate_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="rate_1" value="<?php echo e(old('rate_1')); ?>" autocomplete="rate_1" required>
																	
									</div>

									<div class="col-sm-4">										

										<input id="about_1" type="text" placeholder="Give Reason For your rating" class="form-control <?php $__errorArgs = ['about_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="reason_1" value="<?php echo e(old('about_1')); ?>" autocomplete="about_1" required>
																
									</div>
								</div>

								<h6 class="label">Skill Rate 2</h6>

								<div class="row">
									
									<div class="col-sm-4">										

										<input id="skill_2" type="text" placeholder="Enter a Skill Pertaining to your talent here" class="form-control <?php $__errorArgs = ['skill_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="skill_2" value="<?php echo e(old('skill_2')); ?>" autocomplete="skill_2">
																		
									</div>

									<div class="col-sm-4">										

										<input id="rate_2" type="number" placeholder="Rate your Skill Mentioned" class="form-control <?php $__errorArgs = ['rate_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="rate_2" value="<?php echo e(old('rate_2')); ?>" autocomplete="rate_2">
																	
									</div>

									<div class="col-sm-4">										

										<input id="about_2" type="text" placeholder="Give Reason For your rating" class="form-control <?php $__errorArgs = ['about_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="reason_2" value="<?php echo e(old('about_2')); ?>" autocomplete="about_2">
																
									</div>
								</div>

								<h6 class="label">Skill Rate 3</h6>

								<div class="row">
									
									<div class="col-sm-4">										

										<input id="skill_3" type="text" placeholder="Enter a Skill Pertaining to your talent here" class="form-control <?php $__errorArgs = ['skill_3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="skill_3" value="<?php echo e(old('skill_3')); ?>" autocomplete="skill_3">
																		
									</div>

									<div class="col-sm-4">										

										<input id="rate_3" type="number" placeholder="Rate your Skill Mentioned" class="form-control <?php $__errorArgs = ['rate_3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="rate_3" value="<?php echo e(old('rate_3')); ?>" autocomplete="rate_3">
																	
									</div>

									<div class="col-sm-4">										

										<input id="about_3" type="text" placeholder="Give Reason For your rating" class="form-control <?php $__errorArgs = ['about_3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="reason_3" value="<?php echo e(old('about_3')); ?>" autocomplete="about_3">
																
									</div>
								</div>
							</section>
								
						<hr class="mt60">						
							
						</div>

						<div class="clearfix">
							<!-- <a href="submit" class="btn btn-default btn-large pull-right">Continue to Step 2</a> -->
							<!-- <button type="submit" id="" onclick="call()" class="btn btn-default btn-large pull-right">Continue to Step 2</button> -->
							<button type="submit" class="btn btn-default btn-large pull-right">Submit</button>
						</div>
					</div>
			</form>
				</div> <!-- end .page-content -->
			</div>
		</div> <!-- end .container -->
	</div> <!-- end #page-content -->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
	<!-- <script>
	var headno= 1;
		function call(){
			alert(headno+=1)
		}
	</script> -->
	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\fob\resources\views/auth/register-user.blade.php ENDPATH**/ ?>