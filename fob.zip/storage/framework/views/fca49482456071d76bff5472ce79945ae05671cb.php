    <!--== Footer Area Start ==-->
	<div class="footer-copyright-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="footer-copy-right">
                            <p>Copyright © 2018. All rights reserved. Template by <a href="https://colorlib.com/wp/templates/">Colorlib</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div> <!-- End Footer --><?php /**PATH C:\wamp64\www\fob\resources\views/admin-layouts/footer.blade.php ENDPATH**/ ?>