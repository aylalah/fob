

<!-- <?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?> -->

<?php $__env->startSection('breadcrumb'); ?>


							
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <!-- Single pro tab review Start-->
    <div class="product-status mg-b-15">
            <div class="container-fluid">
                 <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="product-payment-inner-st">
                             <ul id="myTabedu1" class="tab-review-design">
                                <li class="active"><a href="#description">Activities List</a></li>
                                <li><a href="#reviews">Image Gallery</a></li>
                                <li><a href="#INFORMATION">Video Gallery</a></li>
                            </ul>
                            <div class="add-product">
                                <a href="<?php echo e(url('add_activities/')); ?>">Add Activities or Galleries</a>
                            </div>
                            <div id="myTabContent" class="tab-content custom-product-edit">
                                 <div class="product-tab-list tab-pane fade active in" id="description">

                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="product-status-wrap">
                            <!-- <h4>Activities List</h4> -->
                            
                            <div class="asset-inner">
                                <table>
                                    <tr>
                                        <th>No</th>
                                        <th>Image</th>
                                        <th>Name of Category</th>
                                        <th>Status</th>
                                        <th>Tittle</th>
                                        <!-- <th>Content</th> -->
                                        <!-- <th>Title Type</th> -->
                                       <th>Created_by</th>
                                        <th>Updated_by</th>
                                        <th>Created_at</th>
                                        <th>Updated_at</th>
                                        <th>Setting</th>
                                    </tr>
                                     <?php $__currentLoopData = $act; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                    <tr>
                                      <td><?php echo e($index +1); ?></td>
                                     
                                        <td><img src="http://localhost/fob/storage/app/<?php echo e($c->image); ?>" alt="" /></td>
                                        <td><?php echo e($c->category_name); ?></td>
                                        
                                        <td>
                                            <button class="ps-setting"><?php echo e($c->status); ?></button>
                                        </td>
                                        <td><?php echo e($c->tittle); ?></td>
                                        <!-- <td><p style="white-space: pre-line;"><?php echo e($c->content); ?></p></td> -->
                                        <!-- <td><?php echo e($c->title_type); ?></td> -->
                                          <td><?php echo e($c->created_by); ?></td>
                                        <td><?php echo e($c->updated_by); ?></td>
                                        <td><?php echo e($c->created_at); ?></td>
                                        <td><?php echo e($c->updated_at); ?></td>
                                        <td>
                                           <a href="<?php echo e(url('edit_activities/')); ?>/<?php echo e($c->id); ?>"> <button data-toggle="tooltip" title="Edit" class="pd-setting-ed"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button></a>
                                            <a href="<?php echo e(url('delete_activities/')); ?>/<?php echo e($c->id); ?>"><button data-toggle="tooltip" title="Trash" class="pd-setting-ed"><i class="fa fa-trash-o" aria-hidden="true"></i></button></a>
                                        </td>
                                    </tr>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                            <div class="custom-pagination">
								<ul class="pagination">
									<?php echo e($act->links()); ?>

								</ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
             <div class="product-tab-list tab-pane fade" id="reviews">
            <div class="row">
                 <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="courses-area">
            <div class="container-fluid">
                <div class="row">
                      <?php $__currentLoopData = $g_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                    <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                        <div class="courses-inner res-mg-b-30">
                            <div class="courses-title">
                                <a ><img src="http://localhost/fob/storage/app/<?php echo e($c->image_name); ?>"  alt=""></a>
                                <!-- <h2>Apps Development</h2> -->
                            </div>
                           <div class="product-buttons">
                              <a href="<?php echo e(url('delete_actg/')); ?>/<?php echo e($c->gallery_id); ?>">  <button type="button" class="button-default cart-btn">Delete</button></a>
                            </div>
                        </div>
                    </div>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

             </div>
        </div>

        </div>
            </div>
        </div>


            <div class="product-tab-list tab-pane fade" id="INFORMATION">
            <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="courses-area">
            <div class="container-fluid">
                <div class="row">
                      <?php $__currentLoopData = $g_video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                    <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                        
                        <div class="fitvidsjs">
                            <iframe src="https://<?php echo e($c->image_name); ?>" width="500" height="281" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
                        </div>
                       
                       <div class="product-buttons">
                               <a href="<?php echo e(url('delete_actg/')); ?>/<?php echo e($c->gallery_id); ?>"> <button type="button" class="button-default cart-btn">Delete</button></a>
                            </div>
                    </div>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    
                       
                </div>
                </div>
                </div>
                </div>
                </div>

    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin-layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\fob\resources\views/admin-pages/activities.blade.php ENDPATH**/ ?>