      

<!-- <?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?> -->

<?php $__env->startSection('breadcrumb'); ?>


                            
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <!-- Single pro tab review Start-->
    <div class="single-pro-review-area mt-t-30 mg-b-15">
            <div class="container-fluid">
       <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                             <h4>Add Company Category</h4>
                                            <div class="review-content-section">
                                                <div id="dropzone1" class="pro-ad addcoursepro">
                                                    <form  method="POST" action="<?php echo e(url('storeteam')); ?>" enctype='multipart/form-data'>
                                                         <?php echo csrf_field(); ?>
                                                        <div class="row">
                                                            
                                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<div class="form-group">
                                                                <select name="role_id" class="form-control">
                                                                        <option value="none" selected="" disabled="">Select Category</option>
                                                                        <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                                                        <option value="<?php echo e($c->id); ?>"><?php echo e($c->role); ?></option>
                                                                       
                                                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </div>
                                                                <div class="form-group">
                                                                    <input name="team_name" type="text" class="form-control" placeholder="Team Name">
                                                                </div>
                                                                <div class="form-group">
                                                                    <input name="designation" type="text" class="form-control" placeholder="Designation">
                                                                </div>
                                                                 <div class="form-group ">
                                                                  <span>  Team Picture</span>
                                                                     <input name="file"  type="file" />
                                                                 </div>
                                                                 <!-- <div class="form-group">
                                                                    <textarea name="description" placeholder="Description"></textarea>
                                                                </div> -->
                                                         
                                                            </div>
                                                           
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-lg-12">
                                                                <div class="payment-adress">
                                                                    <button type="submit" class="btn btn-primary waves-effect waves-light">Save</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                          </div>
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin-layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\fob\resources\views/admin-pages/add_team.blade.php ENDPATH**/ ?>