

<!-- <?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?> -->

<?php $__env->startSection('breadcrumb'); ?>
     
							
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
              
<div id="page-content">
		<?php if(count($invest) > 0): ?>
		<div class="container">
			<div class="row">
				<div class="col-sm-12 page-content">
					<div class="white-container candidates-search">
						<div class="row">
							<form method="POST" action="<?php echo e(url('search-partner')); ?>" enctype="multipart/form-data">
						<?php echo csrf_field(); ?>
							<div class="col-sm-6">
								<input type="text" class="form-control" name="search" placeholder="Search for company name">
							</div>

						<!-- 	<div class="col-sm-4">
								<select class="form-control">
									<option value="">Select Industry</option>
									<option value="">1</option>
									<option value="">2</option>
									<option value="">3</option>
									<option value="">4</option>
								</select>
							</div> -->

							<div class="col-sm-2">
								<input type="submit" class="btn btn-default btn-block" value="Search">
							</div>
						</form>
						</div>
					</div>

					<div class="clearfix mb30">
					<!-- 	<select class="form-control pull-left">
							<option value="">Sort By</option>
							<option value="">1</option>
							<option value="">2</option>
							<option value="">3</option>
							<option value="">4</option>
						</select> -->

						<ul class="pagination pull-right">
							<?php echo e($invest->links()); ?>

						</ul>
					</div>

					<div class="row">
								<?php $__currentLoopData = $invest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
						<div class="col-sm-6 col-md-4 col-lg-3">
							<div class="partners-item">
								<div class="img">
									<img src="http://localhost/fob/public/upload/<?php echo e($c->image); ?>" alt="">

									<div class="overlay">
										<!-- <h6><?php echo e($c->name); ?></h6> -->
										<p>Company Name: <?php echo e($c->company_industry_category); ?></p>
										<p><strong>Website:</strong> <a href="<?php echo e($c->website); ?>"><?php echo e($c->website); ?></a></p>
									</div>
								</div>

								<div class="meta clearfix">
									<span>CEO Name: <?php echo e($c->ceo_name); ?></span>
									<a href="#" class="btn btn-default fa fa-link"></a>
									<a href="#" class="btn btn-default fa fa-search"></a>
								</div>
							</div>
						</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
						
					</div>

					<div class="clearfix">
						<ul class="pagination pull-right">
							<?php echo e($invest->links()); ?>

						</ul>
					</div>
				</div>
			</div>

		</div>
		<?php endif; ?> <!-- end .container -->
	</div> <!-- end #page-content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\fob\resources\views/pages/partners.blade.php ENDPATH**/ ?>