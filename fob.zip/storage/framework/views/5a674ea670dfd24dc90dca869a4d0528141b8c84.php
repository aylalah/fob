	<header id="header" class="header-style-1">
		<div class="header-top-bar">
			<div class="container">

				<!-- Header Language -->
				<div class="header-language clearfix">
					<ul>
						<li class="active"><a href="#">En</a></li>
						<li><a href="#">Fr</a></li>
						<li><a href="#">De</a></li>
						<li><a href="#">It</a></li>
					</ul>
				</div> <!-- end .header-language -->

				<!-- Bookmarks -->	

			
			<div class="top-right links">

			
			<?php if(Route::has('login')): ?>
			<?php if(auth()->guard()->check()): ?>
					<a class="btn btn-link bookmarks" href="<?php echo e(route('logout')); ?>"
						onclick="event.preventDefault();
										document.getElementById('logout-form').submit();">
						<?php echo e(__('Logout')); ?>

					</a>

					<a id="navbarDropdown"  class="btn btn-link bookmarks" href="<?php echo e(url('home/')); ?>" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
						<?php echo e(Auth::user()->name); ?> <span class="caret"></span>
					</a>


					<a href="<?php echo e(url('/home')); ?>" class="btn btn-link bookmarks">Profile</a>

					<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
						<?php echo csrf_field(); ?>
					</form>
			
					
				<?php else: ?>

				<!-- <a href="<?php echo e(url('/register-invest')); ?>" class="btn btn-link bookmarks">Sponsor</a> -->

					<?php if(Route::has('register')): ?>
						<!-- <a href="<?php echo e(route('register')); ?>">Register</a> -->

						<!-- Header Register -->
						<div class="header-register">
							<a href="#" class="btn btn-link">Register</a>
							<div>
							<form method="POST" action="<?php echo e(route('register')); ?>">
								<?php echo csrf_field(); ?>
								<select  id="country" class="form-control <?php $__errorArgs = ['user_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="user_category_id" value="<?php echo e(old('user_category_id')); ?>" required autocomplete="user_category_id">
											<option value="">Select Role</option>
											<option value="2">Talent</option>
											<option value="3">Member</option>
											<option value="4">Sponsor</option>
										</select>
										<?php $__errorArgs = ['user_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<span class="invalid-feedback" role="alert">
											<strong><?php echo e($message); ?></strong>
										</span>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								<input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Username" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
								<!-- <input name="user_category_id" type="hidden" value="2"> -->
									<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<span class="invalid-feedback" role="alert">
											<strong><?php echo e($message); ?></strong>
										</span>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

								<input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  placeholder="Email" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

									<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<span class="invalid-feedback" role="alert">
											<strong><?php echo e($message); ?></strong>
										</span>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	
								<input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password" name="password" required autocomplete="new-password">

									<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<span class="invalid-feedback" role="alert">
											<strong><?php echo e($message); ?></strong>
										</span>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

									<input id="password-confirm" type="password" class="form-control" name="password_confirmation" placeholder="Confirm Password " required autocomplete="new-password">
									
									<button type="submit" class="btn btn-default">
										<?php echo e(__('Register')); ?>

									</button>
								</form>
							</div>
						</div> <!-- end .header-register -->

					<?php endif; ?>

							<!-- Header Login -->
				<div class="header-login">
					<a href="#" class="btn btn-link">Login</a>
					<div>
					<form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <!-- <label for="email" class="col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label> -->

                            <div class="col-md-12">
                                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <!-- <label for="password" class="col-form-label text-md-right"><?php echo e(__('Password')); ?></label> -->

                            <div class="col-md-12">
                                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required>

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                    <label class="form-check-label" for="remember">
                                        <?php echo e(__('Remember Me')); ?>

                                    </label>
                                </div>
                    
                                <button type="submit" class="btn btn-default">
                                    <?php echo e(__('Login')); ?>

                                </button>

                                <?php if(Route::has('password.request')): ?>
                                    <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Forgot Your Password?')); ?>

                                    </a>
                                <?php endif; ?>
                           
                    </form>
					</div>
				</div> <!-- end .header-login -->					
				<?php endif; ?>
				<?php endif; ?>  
			
			</div>
		          		
<?php 
$talentCat = \App\TalentCategory::get();
?>		

			</div> <!-- end .container -->
		</div> <!-- end .header-top-bar -->

		<div class="header-nav-bar">
			<div class="container">

				<!-- Logo -->
				<div class="css-table logo">
					<div class="css-table-cell">
						<a  href="<?php echo e(url('/')); ?>">
							<img  src="<?php echo e(asset('img/logo7.png')); ?>" alt="Logo">
						</a> <!-- end .logo -->
					</div>
				</div>

				<!-- Mobile Menu Toggle -->
				<a href="#" id="mobile-menu-toggle"><span></span></a>

				<!-- Primary Nav -->
				<nav>
					<ul class="primary-nav">
						<li><a href="<?php echo e(url('/')); ?>">Home</a></li>
						<li class="has-submenu">
							<a href="<?php echo e(url('talents/')); ?>">Talents</a>
							<ul>
								<?php $__currentLoopData = $talentCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                                  
									            
								<li><a href="<?php echo e(url('candidate-category')); ?>/<?php echo e($gCat->id); ?>"><?php echo e($gCat->talentcategory_name); ?> </a></li>
							
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								
								<!-- <li><a href="<?php echo e(url('/talents')); ?>">More</a></li> -->
							</ul>
						</li>
						<li><a href="<?php echo e(url('candidate/')); ?>">Candidates</a></li>
						<li><a href="<?php echo e(url('partners/')); ?>">Investors</a></li>
						<li class="has-submenu">
							<a href="<?php echo e(url('about/')); ?>">More</a>
							<ul>
								<li><a href="<?php echo e(url('partners/')); ?>">Activities</a></li>
								<li><a href="<?php echo e(url('partners/')); ?>">News</a></li>								
							</ul>
						<li class="has-submenu">
							<a href="<?php echo e(url('about/')); ?>">About Us</a>
							<ul>
								<li><a href="<?php echo e(url('partners/')); ?>">Partners</a></li>								
							</ul>
						</li>
						<li><a href="<?php echo e(url('contact/')); ?>">Contact Us</a></li>					
					</ul>
				</nav>
			</div> <!-- end .container -->

			<div id="mobile-menu-container" class="container">
				<div class="login-register"></div>
				<div class="menu"></div>
			</div>
		</div> <!-- end .header-nav-bar -->

		<?php echo $__env->yieldContent('breadcrumb'); ?>
		
	</header> <!-- end #header -->
    <?php /**PATH C:\wamp64\www\fob\resources\views/layouts/header.blade.php ENDPATH**/ ?>