(function ($) {
 "use strict";
 
	$('.chosen-select').chosen({width: "100%"});
	
 
})(jQuery); 