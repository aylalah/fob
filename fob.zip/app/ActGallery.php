<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ActGallery extends Model
{
    //
    protected $fillable = [
        'activities_id', 'gallery_id','status'
    ];
}
