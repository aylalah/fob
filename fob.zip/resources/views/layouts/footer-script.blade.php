  <!-- Scripts -->
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/jquery-1.11.0.min.js"><\/script>')</script>
        <script src="http://maps.google.com/maps/api/js?sensor=false&libraries=geometry&v=3.7"></script>
        <script src="{{ asset('js/maplace.min.js') }}"></script>
        <script src="{{ asset('js/jquery.ba-outside-events.min.js') }}"></script>
        <script src="{{ asset('js/jquery.responsive-tabs.js') }}"></script>
        <script src="{{ asset('js/jquery.flexslider-min.js') }}"></script>
        <script src="{{ asset('js/jquery.fitvids.js') }}"></script>
        <script src="{{ asset('js/jquery-ui-1.10.4.custom.min.js') }}"></script>
        <script src="{{ asset('js/jquery.inview.min.js') }}"></script>
        <script src="{{ asset('js/script.js') }}"></script>
<!-- custom js: custom scripts for theme style switcher for demo purpose  -->

       

      
        
        @yield('script-bottom')